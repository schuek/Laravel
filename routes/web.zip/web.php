<!--

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Usuario;

Route::get('/', function () {
    return view('welcome'); //ruta básica
});

Route::get('/usuario/{id}', function ($id) {
    return "El ID del usuario es: " . $id;
});

Route::get('/contacto', function () {
    return "Página de contacto";
})->name('contacto'); //contacto

$urlContacto = route('contacto');

Route::middleware(['auth'])->prefix('admin')->group(function () {


    Route::get('/usuarios', function () {
        return "Gestión de usuarios";
    });

    Route::get('/configuracion', function () {
        return "Configuración del sistema";
    });
});
-->
<?php

use Illuminate\Support\Facades\Route;
// use App\Http\Controllers\Usuario; // Comenta esto si no tienes el controlador creado aún, a veces da error.

// 1. Ruta básica
Route::get('/', function () {
    return view('welcome');
});

// 2. Ruta con parámetros
Route::get('/usuario/{id}', function ($id) {
    return "El ID del usuario es: " . $id;
});

// 3. Rutas con nombres
Route::get('/contacto', function () {
    return "Página de contacto";
})->name('contacto');

// asignado
Route::get('/prueba-url', function () {
    $urlContacto = route('contacto');
    return "La URL generada en la variable es: " . $urlContacto;
});

// 4. Rutas generales
Route::middleware(['auth'])->group(function () {

    Route::get('/admin/usuarios', function () {
        return "Gestión de usuarios";
    });

    Route::get('/admin/configuracion', function () {
        return "Configuración del sistema";
    });
});


